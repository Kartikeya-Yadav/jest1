import { Response } from "express";
import { leaveService } from "../services/leaveService";
import { Request } from "express";

export const getUsersHandler = async (req: Request, res: Response)=>{
    try {
        const users = await leaveService.getAllLeaves();
        res.status(200).json(users);
    } catch (error) {
        res.status(500).json({ error: (error as Error).message });
    }
}
