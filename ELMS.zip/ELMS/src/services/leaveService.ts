import leaveRepository from "../repository/leaveRepository";


class LeaveService {

    async getAllLeaves() {
        try {
            const result = leaveRepository.getAllLeaves();
            return result;
        } catch (error) {
            throw error;
        }
    }
}

export const leaveService = new LeaveService();